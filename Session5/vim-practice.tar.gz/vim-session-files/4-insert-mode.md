
> make the first line the same as the second line 

> i, a

---> There is text misng this .
---> There is some text missing from this line.

---

> make the first line the same as the second line

> I


some text missing from this line. <---
There is some text missing from this line.



---

> make the first line the same as the second line

> A

---> There is some text missing from th
     There is some text missing from this line.

---


> make the first block the same as the second block


> o, O

line 2 <--


line 1
line 2
line3 

---
