Locate what you can't see.
Find out what to do with it.
